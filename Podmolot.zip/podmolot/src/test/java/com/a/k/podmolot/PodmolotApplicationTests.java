package com.a.k.podmolot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PodmolotApplicationTests {

	@Test
	void contextLoads() {
	}

}
